//
//  TemaItem.swift
//  TemasRowEnsayo
//
//  Created by Luis Miguel Zuluaga Gonzalez on 24/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI


struct TemaItem: View {
    
    var temasparametros: TemasParametros
    
    var body: some View {
        
        HStack {
            temasparametros.image
                .renderingMode(.original)
                .resizable()
                .frame(width: 40, height: 40)
                .cornerRadius(5)
            Text(temasparametros.nTema)
                .foregroundColor(.primary)
                .font(.caption)
        }
    }
}

struct TemaItem_Previews: PreviewProvider {
    static var previews: some View {
        TemaItem(temasparametros: temasData[0])
    }
}
