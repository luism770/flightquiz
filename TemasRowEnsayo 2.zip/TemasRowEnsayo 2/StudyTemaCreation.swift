//
//  StudyTemaCreation.swift
//  Prueba 3
//
//  Created by Luis Miguel Zuluaga Gonzalez on 4/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI

struct StudyTemaCreation: View {
  
   var temasparametros : TemasParametros
    
 //   var acces : TemasParametros.PreguntasParametros
    
    var body: some View {
        
        VStack{
            
      //      Text(temasparametros.cantidadPreguntas)
            
            
            Text(temasparametros.cantidadPreguntas)
            
            
            //NEEDED PARAMETERS HERE:
            
            // ePregunta
            // opcionA
            // opcionB
            // epcionC
            // opcionD
            
            //CANT GET ACCES TO IT info IN THE JSON DATA
            
            // each parameter belongs to a question, each question belongs to a subject
      
        }
    }
}

struct StudyTemaCreation_Previews: PreviewProvider {
    static var previews: some View {
        StudyTemaCreation(temasparametros: temasData[0])
        
    }
}
