//
//  TemasRow.swift
//  Prueba 3
//
//  Created by Luis Miguel Zuluaga Gonzalez on 4/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI

struct TemasRow: View {
    
   var temasparametros : [TemasParametros]
    
    var body: some View {
        VStack{
            List(self.temasparametros){ tema in
                NavigationLink(destination: StudyTemaCreation(temasparametros:temasData[0])){
                    
                    
                    HStack(spacing: 25){
                        Text(tema.nTema)
                        
                        Image(tema.imageName)
                            .resizable()
                            .renderingMode(.original)
                            .frame(width: 40, height: 40)
                        
                        Text(tema.tema)
                        
                        Spacer()
                        
                        Text(tema.cantidadPreguntas)
                    }
                }.padding(.horizontal)
            }
        }
    }
}

struct ItemRow: View {
    
    var temasparametros : TemasParametros
    
    var body: some View {
        HStack(spacing: 25){
            Text(temasparametros.nTema)
            
            Image(temasparametros.imageName)
                .resizable()
                .renderingMode(.original)
                .frame(width: 40, height: 40)
            
            Text(temasparametros.tema)
            
            Spacer()
            
            Text(temasparametros.cantidadPreguntas)
        }
    }
}

struct TemasRow_Previews: PreviewProvider {
    static var previews: some View {
        TemasRow(temasparametros: temasData).environmentObject(UserData())
    }
}
