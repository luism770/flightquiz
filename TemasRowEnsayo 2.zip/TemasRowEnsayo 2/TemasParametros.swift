//
//  TemasParametros.swift
//  Prueba 3
//
//  Created by Luis Miguel Zuluaga Gonzalez on 4/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI

struct TemasParametros: Hashable, Codable, Identifiable {
    
    var id: Int
    var nTema: String
    var tema: String
    var cantidadPreguntas : String
    
    var imageName: String
    
    var preguntas: [PreguntasParametros]
    
    struct PreguntasParametros: Hashable, Codable, Identifiable {
        
        var id: Int
        var nPregunta: String
        var ePregunta: String
        var opcionA: String
        var opcionB: String
        var opcionC: String?
        var opcionD: String?
        var opcionE: String?
        var rPregunta: String
        
        enum CodingKeys: String, CodingKey {
            case id = "id"
            case nPregunta = "nPregunta"
            case ePregunta = "ePregunta"
            case opcionA = "opcionA"
            case opcionB = "opcionB"
            case opcionC = "opcionC"
            case opcionD = "opcionD"
            case opcionE = "opcionE"
            case rPregunta = "rPregunta"
        }
    }
}

extension TemasParametros.PreguntasParametros {
    init(from decoder: Decoder) throws {
        
        let values = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try values.decode(Int.self, forKey: .id)
        self.nPregunta = try values.decodeIfPresent(String.self, forKey: .nPregunta) ?? ""
        self.ePregunta = try values.decodeIfPresent(String.self, forKey: .ePregunta) ?? ""
        self.opcionA = try values.decodeIfPresent(String.self, forKey: .opcionA) ?? ""
        self.opcionB = try values.decodeIfPresent(String.self, forKey: .opcionB) ?? ""
        self.opcionC = try values.decodeIfPresent(String.self, forKey: .opcionC) ?? ""
        self.opcionD = try values.decodeIfPresent(String.self, forKey: .opcionD) ?? ""
        self.opcionE = try values.decodeIfPresent(String.self, forKey: .opcionE) ?? ""
        self.rPregunta = try values.decodeIfPresent(String.self, forKey: .rPregunta) ?? ""
    }
}

extension TemasParametros {
    var image: Image {
        ImageStore.shared.image(name: imageName)
    }
}

struct TemasParametros_Previews: PreviewProvider {
    static var previews: some View {
        Text("TemasParametros")
    }
}
