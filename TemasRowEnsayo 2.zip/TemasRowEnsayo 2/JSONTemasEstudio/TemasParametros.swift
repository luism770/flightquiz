//
//  TemasParametros.swift
//  Prueba 3
//
//  Created by Luis Miguel Zuluaga Gonzalez on 4/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI

struct TemasParametros: Hashable, Codable, Identifiable {
    
    var id: Int
    var nTema: String
    var categorias: TemasCompleto
    var tema: String
    var cantidadPreguntas : String
    var npregunta: String
    var ePregunta: String
    var opcionA: String
    var opcionB: String
    var opcionC: String
    var opcionD: String
    var opcionE: String
    var rPregunta: String
    
    fileprivate var imageName: String

}

enum TemasCompleto: String, CaseIterable, Codable, Hashable {
    case TemasCompletos = "TemasCompletos"
}

extension TemasParametros {
    var image: Image {
        ImageStore.shared.image(name: imageName)
    }
}

struct TemasParametros_Previews: PreviewProvider {
    static var previews: some View {
        Text("TemasParametros")
    }
}
