//
//  TemasRow.swift
//  Prueba 3
//
//  Created by Luis Miguel Zuluaga Gonzalez on 4/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI

struct TemasRow: View {
    
    var categoriaNombre: String
    var items: [TemasParametros]
    
    
    var body: some View {
        
        VStack{

            List{
                ForEach(self.items) { temasparametros in
                  
                TemaItem(temasparametros: temasparametros)
                                
                                }
                }
            }
        }
    }


struct TemaItem: View {
    
    var temasparametros: TemasParametros
    
    var body: some View {
        
        HStack {
            temasparametros.image
                .renderingMode(.original)
                .resizable()
                .frame(width: 40, height: 40)
                .cornerRadius(5)
            Text(temasparametros.nTema)
                .foregroundColor(.primary)
                .font(.caption)
        }
    }
}

struct TemasRow_Previews: PreviewProvider {
    static var previews: some View {
        TemasRow(
            categoriaNombre: temasData[0].categorias.rawValue,
            items: Array(temasData.prefix(3))
        )
    }
}
