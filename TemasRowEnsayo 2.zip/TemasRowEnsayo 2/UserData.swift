//
//  UserData.swift
//  TemasRowEnsayo
//
//  Created by Luis Miguel Zuluaga Gonzalez on 29/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI
import Combine

final class UserData: ObservableObject {
   
    @Published var temasparametros = temasData

}

