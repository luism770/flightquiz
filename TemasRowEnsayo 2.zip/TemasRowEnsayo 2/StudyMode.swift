//
//  StudyMode.swift
//  Prueba 3
//
//  Created by Luis Miguel Zuluaga Gonzalez on 4/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI

struct StudyMode: View {
    
    var temasparametros : TemasParametros
    
        var body: some View {
            
            VStack{
              
                TemasRow(temasparametros: temasData)
  
            }
        }
    }
struct StudyMode_Previews: PreviewProvider {
    static var previews: some View {
        StudyMode(temasparametros: temasData[0]).environmentObject(UserData())
    }
}

