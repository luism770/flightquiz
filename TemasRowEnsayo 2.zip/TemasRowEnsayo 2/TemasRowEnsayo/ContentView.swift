//
//  ContentView.swift
//  TemasRowEnsayo
//
//  Created by Luis Miguel Zuluaga Gonzalez on 24/04/20.
//  Copyright © 2020 Luis Miguel Zuluaga Gonzalez. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            
            NavigationLink(destination: StudyMode(temasparametros: temasData[0])){
                Text("LINK A PAGINA STUDYMODE")}
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
